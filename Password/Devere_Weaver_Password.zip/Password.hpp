#ifndef PASSWORD_HPP
#define PASSWORD_HPP

#include <string>

class Password
{
	public:
		Password(){};
		// TO DO: maybe make another constructor, but seems pointless 
		bool IsValidPassword();	
		std::string getPassword();
		bool setPassword();
	private:
		std::string password{};

};

#endif
